  int a = 10; 
  aas2s_a=2.5;    //sa"sd"ss
  float b_ = 2.8e-6;
  /* for 
  xunhuan */
  for( ; i <= 4  && c != 5 || x == s ; i++){
      c = 5e+7 ;
  }
  str = "sde85f af@f$";
  return 0;
